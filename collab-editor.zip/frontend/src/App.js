import React from "react";
import Editor from "./Editor";

function App() {
  return <Editor documentId="my-doc-id" />;
}

export default App;