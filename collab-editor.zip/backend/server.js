const express = require('express');
const http = require('http');
const cors = require('cors');
const mongoose = require('mongoose');
const socketIO = require('socket.io');
const Document = require('./models/Document');

const app = express();
const server = http.createServer(app);
const io = socketIO(server, {
  cors: {
    origin: "*"
  }
});

app.use(cors());
app.use(express.json());

mongoose.connect("mongodb://localhost:27017/collab-docs");

app.get('/documents/:id', async (req, res) => {
  const doc = await Document.findById(req.params.id);
  res.send(doc);
});

io.on('connection', (socket) => {
  console.log('A user connected');

  socket.on('get-document', async (docId) => {
    const document = await Document.findById(docId) || await Document.create({ _id: docId, data: "" });
    socket.join(docId);
    socket.emit('load-document', document.data);

    socket.on('send-changes', delta => {
      socket.broadcast.to(docId).emit('receive-changes', delta);
    });

    socket.on('save-document', async data => {
      await Document.findByIdAndUpdate(docId, { data });
    });
  });
});

server.listen(3001, () => console.log('Server running on port 3001'));